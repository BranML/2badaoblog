/*
 FireShot - Webpage Screenshots and Annotations
 Copyright (C) 2007-2019 Evgeny Suslikov (evgeny@suslikov.ru)
*/
var scriptLoaded;chrome.runtime.sendMessage({message:"undefined"==typeof scriptLoaded?"loadScript":"execScript"});
